/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

/**
 *
 * @author MP
 */
public class Service extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String s1 = request.getParameter("From");
        String s2 = request.getParameter("To");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */

            FileInputStream inputStream = new FileInputStream("/home/mtech/Desktop/courierChart.xls");
            Workbook workbook = new HSSFWorkbook(inputStream);
            Sheet firstSheet = workbook.getSheetAt(0);
            Iterator<Row> it = firstSheet.iterator();
            double d, d1;
            d = d1 = 0;

            while (it.hasNext()) {
                Row nextRow = 
                Cell cell = nextRow.getCell(1);
                String s = cell.toString();
                System.out.println(s);
                if (s.equalsIgnoreCase(s1)) {
                    Row i = cell.getRow();
                    Cell j = i.getCell(2);
                    System.out.println("");
                    if (j.toString().equalsIgnoreCase(s2)) {

                        out.print("<br><br><table border=1px><tr><th>curier</th><th>From<th>To</th><th>TotalFair</th><th>TotalTime</th></tr><tr><td> " + i.getCell(0) + "</td><td>" + s + "</td><td>" + j.toString() + "</td><td>" + i.getCell(3).getNumericCellValue() + "</td><td>" + i.getCell(4).getNumericCellValue() + "</td></tr></table>");
                    } else {

                        String h = j.toString();
                        System.out.println(h);

                        for (int o = 1; o <= (firstSheet.getLastRowNum()); o++) {
                            Row r = firstSheet.getRow(o);
                            Cell c = r.getCell(1);
                            String C = c.toString();
                            if (C.equals(h)) {

                                Row i1 = c.getRow();
                                System.out.println("row is" + i1.getRowNum());
                                Cell j1 = i1.getCell(2);
                                System.out.println("here");
                                System.out.println(j1.toString());
                                if (j1.toString().equalsIgnoreCase(s2)) {
                                    out.print("<br><br><table border=1px><tr><th>curier</th><th>From<th>To</th><th>TotalFair</th><th>TotalTime</th></tr><tr><td> " + i.getCell(0) + "</td><td>" + s + "</td><td>" + j.toString() + "</td></tr><tr><td>" + i1.getCell(0) + "</td><td>" + j.toString() + " </td><td>" + j1.toString() + "</td><td>" + (i.getCell(3).getNumericCellValue() + i1.getCell(3).getNumericCellValue()) + "</td><td>" + (i.getCell(4).getNumericCellValue() + i1.getCell(4).getNumericCellValue()) + "</td></tr></table>");

                                }
                            }
                        }
                    }

                }

            }

            //  out.println("<head>");
            // out.println("<title>Servlet Service</title>");            
            // out.println("</head>");
            //out.println("<body>");
            //out.println("<h1>Servlet Service at " + request.getContextPath() + "</h1>");
            //out.println("</body>");
            //out.println("</html>");
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
